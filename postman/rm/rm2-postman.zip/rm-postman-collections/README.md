# Risk Modeler 2.0 Postman README
The Risk Modeler 2.0 Postman package enables developers to quickly and easily to evaluate Risk Modeler 2.0 calls.  

The Risk Modeler 2.0 Postman package consists of a [Postman Collection](https://www.postman.com/collection/) and three [Postman Environment](https://learning.postman.com/docs/sending-requests/managing-environments/) file.


* **Risk Modeler 2.0 APIs**. The Risk Modeler 2.0 Postman Collection (`rm2-postman-collection.json`) is a Postman Collection for testing and evaluation. The Postman Collection groups related requests into discreet folders. 
* **Risk Modeler 2.0 APIs Environment**. A Risk Modeler 2.0 environment is a collection of variables that define the setup of an environment. Each Risk Modeler 2.0 environment file defines environmental variables needed to connect to Risk Intelligence including the `env_url`, `auth_url`, `user`, and `password`. We make three environment files available: Risk Modeler 2.0 Environment EU West (`rm2-prod-environment-eu-west1.json`), Risk Modeler 2.0 Environment US East (`rm2-prod-environment-us-east1.json`), or Risk Modeler 2.0 Environment Template (`rm2-environment-template.json`).

## Prerequisites

* Download and install [Postman](https://learning.postman.com/docs/getting-started/installation-and-updates/).
* Gather your user credentials (unique username and password) and environment details (`env_url`, `auth_url`, `tenant`) from your tenant administrator. You will need to specify these values in the Risk Modeler 2.0 Environment. 


## Step 1: Import Postman files 

In this step, you will import the Postman Collection file and the Postman Environment file into the Postman application.

1. Open the Postman application.
2. Select File > Import in the menu bar. 

	The Import window appears.
3. Drag and drop the Risk Modeler 2.0 Collection (`rm2-postman-collection.json`) into the import window.
4. Drag and drop an environmental file into the import window. 
  * The Risk Modeler 2.0 Environment Template (`rm2-environment-template.json`) is a template for creating a custom environment.
  * The Risk Modeler 2.0 Environment EU West (`rm2-prod-environment-eu-west1.json`) defines environmental variables for tenants using the EU data center.
  * The Risk Modeler 2.0 Environment US East (`rm2-prod-environment-us-east1.json`) defines environmental variables for tenants using the US data center.
4. Click Import.

The imported Postman Collection is displayed in the Postman Collection pane as *Risk Modeler 2.0 APIs*. 

The imported Postman environment is displayed in the Environment dropdown list: *Risk Modeler 2.0 Environment Template*, *Risk Modeler 2.0 Environment EU West*, or *Risk Modeler 2.0 Environment US East*.

## Step 2: Set up Postman environments

In this step, you will define or edit the environmental variables in the Risk Modeler 2.0 Custom environment. 


1. Open Postman.
2. Click Manage Environments (gear button) in the top right of Postman. 

	The Manage Enviroments window appears.

3. Select the Risk Modeler 2.0 Custom in the Manage Environment window. 
4. Define the following six environmental variables.

	* `env_url`:    Specifies the base URL for all service endpoints in the Postman Collection. The `env_url` is tied to the data center at which your tenant was provisioned. 
	* `auth_url`: Specifies the base URL (root endpoint) for all calls to the RMS Authentication Service in the Postman Collection. The `auth_url` is tied to the data center at which your tenant was provisioned. 
	* `user`: Specifies your user name; usually an email address that has been registered with RMS.  For example, `user.name@company.com`. 
	* `password`:   Specifies a unique password that is associated with your user credential. For example, `password@123`. During onboarding, your tenant admin will send you an email that contains your username (i.e. the `user` variable) and a link that will enable you to define your password. The link is valid for 24 hours. 
	* `edm_name`:     Specifies the name of the Exposure Data Module in the testing environment. For example, `my_test_edm`.
	* `tenantName`:  Specifies the name of your tenant. Your tenant administrator can provide you with the name of a tenant. 

5. Click the Update button. 

## Step 3: Making calls

Once you have the Postman Collection and the Postman Environment, you are ready to test the Risk Modeler 2.0 APIs.

1. Run the commands in the Setup folder to retrieve an authentication token and to create the EDM that you will use to test the Risk Modeler 2.0 APIs. (The authentication token expires in 30 minutes.)  
2. Work sequentially from the top of the Postman Collection to the bottom. 
3. Run the commands in the Teardown folder to delete the EDM and reset the environment.


